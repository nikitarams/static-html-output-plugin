<?php
namespace Aws\Common\Exception;
class RequiredExtensionNotLoadedException extends RuntimeException {}
