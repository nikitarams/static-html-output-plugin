<?php
namespace Aws\Common\Exception;
class OverflowException extends \OverflowException implements AwsExceptionInterface {}
